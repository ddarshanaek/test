package dark.test.test;

import dark.test.dark.AppTest;

public class TestDark {
	AppTest a;

}
