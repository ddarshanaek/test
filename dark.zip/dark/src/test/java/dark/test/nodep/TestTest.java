package dark.test.nodep;

public class TestTest {

	public static void main(String args[]) {
		System.out.println("M");
	}
}
