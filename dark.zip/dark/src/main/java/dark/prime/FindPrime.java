package dark.prime;

public class FindPrime {

	public static void main(String args[]) {
		System.out.println(isPrime(323434344));
	}
	
	static boolean isPrime(int p) {
		boolean isPrime = true;
		for(int i=2; i < p; i++) {
			if(p%i == 0) {
				isPrime = false;
				break;
			}
		}
		
		return isPrime;
	}
}
