package dark.comparator;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class ComparatorTest {

	public static void main(String args[]) {
		List<Student> list = new ArrayList<Student>();
		
		Student a = new Student(); a.setName("Kule"); a.setAge(10);
		Student b = new Student(); b.setName("Wimal"); b.setAge(12);
		Student c = new Student(); c.setName("Darshana"); c.setAge(13); 
		Student d = new Student(); d.setName("Shushi"); d.setAge(14);
		Student e = new Student(); e.setName("Darshana"); e.setAge(13); 
		
		list.add(a); list.add(b); list.add(c); list.add(d); list.add(e);
		
		Collections.sort(list, new StudentSortByName());
		
		System.out.println(list);
		
	}
	
}

class Student{
	private String name;
	private int age;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	
	@Override
	public String toString() {
		return this.name + "--" + age;
	}
	
}

class StudentSortByName implements Comparator<Student>{

	public int compare(Student o1, Student o2) {
		int nameCompare = o1.getName().compareTo(o2.getName());
		int ageCompare = o1.getAge()-o2.getAge();
		
		if(nameCompare==0) {
			return ageCompare;
			 
		}else {
			return nameCompare;
		}
		
	}
	
}
