package dark.mergelink;

public class MergeLinkList {

	public static void mergeLinkList(Node root1, Node root2, Node newRoot) {

		if (root1 == null || root2 == null) {
			return;
		}

		if (root1.data < root2.data) {
			if (newRoot!=null && newRoot.data == -1) {
				newRoot.data = root1.data;
			} else {
				newRoot = root1;
			}

			mergeLinkList(root1.next, root2, newRoot.next);
		}
		if (root1.data < root2.data) {
			if (newRoot!=null && newRoot.data == -1) {
				newRoot.data = root2.data;
			} else {
				newRoot = root2;
			}

			mergeLinkList(root1, root2.next, newRoot.next);
		}

	}
	
	public static void main(String args[]) {
		Node root1=new Node(1);
		root1.next=new Node(2);
		root1.next.next=new Node(3);
		
		Node root2=new Node(4);
		root2.next=new Node(5);
		root2.next.next=new Node(6);
		
		Node newRoot = new Node(-1);
		
		
		mergeLinkList(root1,root2,newRoot);
		System.out.println(newRoot);
	}

	static class Node {
		int data;
		Node next;

		Node(int data) {
			this.data = data;
		}
	}
}
