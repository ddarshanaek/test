package dark.linklist;

public class LinkListTest {

	public static void main(String args[]) {
		Node root = new Node(1);
		root.next = new Node(2);
		root.next.next = new Node(3);
		root.next.next.next = new Node(4);
		root.next.next.next.next = new Node(5);
		deleteNode(root.next.next);
		printAll(root);

	}

	static void deleteNode(Node del) {
		// Your code here
		if(del==null) return;
		
		if(del.next!=null) {
			del.data = del.next.data;
			del.next = del.next.next;
			
		}
		//deleteNode(del.next, root);
		
	}
	static void printAll(Node root) {
		if(root==null) {
			return;
		}
		System.out.println(root.data);
		printAll(root.next);
		
	}

}

class Node {
	int data;
	Node next;

	Node(int d) {
		data = d;
		next = null;
	}
}