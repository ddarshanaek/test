package dark.stack;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;
import java.util.Stack;

public class EqualStack {
	
	static int equalStacks(int[] h1, int[] h2, int[] h3) {
	    Stack<Integer> s1 = new Stack<Integer>();
	    Stack<Integer> s2 = new Stack<Integer>();
	    Stack<Integer> s3 = new Stack<Integer>();
	    
	    int h1Height=0;
	    int h2Height=0;
	    int h3Height=0;
	    
	    
	    for (int i = h3.length-1; i >=0; i--) {
			s3.push(h3[i]);
			h3Height = h3Height + h3[i];
			
		}

	    for (int i = h2.length-1; i >=0; i--) {
			s2.push(h2[i]);
			h2Height = h2Height + h2[i];
			
	    }

	    for (int i = h1.length-1; i >=0 ; i--) {
			s1.push(h1[i]);
			h1Height = h1Height + h1[i];
			
		}
	    
		int soFarMinHight = Math.min( Math.min(h3Height, h2Height), h1Height);
		
		for(int i = soFarMinHight; i>0 ; i--) {
			
			if(h1Height == h2Height &&  h2Height == h3Height) {
				return h1Height;
			}
			
			if(soFarMinHight < h1Height) {
				h1Height = h1Height - s1.pop();
			}
			if(soFarMinHight < h2Height) {
				h2Height = h2Height - s2.pop();
			}
			if(soFarMinHight < h3Height) {
				h3Height = h3Height - s3.pop();
			}
			
			soFarMinHight = Math.min( Math.min(h3Height, h2Height), h1Height);
			
		}
		return 0;
	    
	}
	
    private static final Scanner scanner = new Scanner(System.in);


	public static void main(String[] args) throws IOException {
		int h1[]  = {3 ,2, 1, 1, 1};
		int h2[] = {4,3,2};
		int h3[] = {1,1,4,1};
        int result = equalStacks(h1, h2, h3);
        System.out.println(result);

    }

}


//


//5 3 4
//3 2 1 1 1  == 8
//    4 3 2      == 9
//  1 1 4 1	 == 7

// can it be 7   --> bcz 8-3 ==5 sofarminhight == 5
// can it be 6   -->  not okay bcz sofarmingiht is 5 { 7-1 ok but 9-4} no need this step to check
// can it be 5 ---> can it be 5 ? 8-3 ok 9-4=ok 7-1-1=ok



