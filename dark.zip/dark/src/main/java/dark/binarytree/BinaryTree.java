package dark.binarytree;

public class BinaryTree {
	
	static int levelDiff(Node root) {
		
		int []count = new int[]{0,0};
	    levelDiff(root, 1, count);
	    return count[1]-count[0];
	}
	
	private static void levelDiff(Node root, int level, int[] count) {
		
		if(root == null) {
			return;
		}
		if(level%2==0) {
			count[0] = count[0]+root.data;
		}else {
			count[1] = count[1]+root.data;
		}
		
		if(root.left!=null) {
			levelDiff(root.left, level+1, count);
		}
		if(root.right!=null) {
			levelDiff(root.right,level+1,count);
		}
		
	}

	static int hightOfBT(Node root) {
		if(root==null) {
			return 0;
		}
		
		return Math.max(hightOfBT(root.left)+1, hightOfBT(root.right)+1);
		
	}
	
	
	public static void main(String args[]) {
		Node root = new Node(1);
		root.left = new Node(2);
		root.right = new Node(3);
		//root.left.left = new Node(1);
		System.out.println(hightOfBT(root));
		System.out.println(levelDiff(root));
		
		//10 20 L 10 30 R 20 40 L 20 60 R
		Node root2 = new Node(10);
		root2.left = new Node(20);
		root2.right = new Node(30);
		root2.left.left=new Node(40);
		root2.left.right=new Node(60);
		System.out.println(levelDiff(root2));
		
	}

}



class Node
{
    int data;
    Node left, right;
    Node(int item)
    {
        data = item;
        left = right = null;
    }
}