package dark.binarytree;

import java.util.LinkedList;
import java.util.Queue;
import java.util.Stack;

public class ExpressionTree {
	
	static int evealuateExp(Node root) {
		Queue<Node> queue = new LinkedList<Node>();
		readTree(root, queue);
		int finalAnswer=0;
		int a=0; int b=0;
		while(!queue.isEmpty()) {
			String tmp = queue.remove().data;
			if(tmp.equals("-")) {
				finalAnswer = (a-b)+finalAnswer;
				a=0;b=0;
			} else if(tmp.equals("+")){
				finalAnswer = (a+b)+finalAnswer;
				a=0;b=0;
			}else if(tmp.equals("/")){
				finalAnswer = (a/b)+finalAnswer;
				a=0;b=0;
			}else if(tmp.equals("*")){
				finalAnswer = (a*b)+finalAnswer;
				a=0;b=0;
			}
			else {
				if(a==0) {
					a=Integer.parseInt(tmp);
				}else {
					b=Integer.parseInt(tmp);
				}
				
				
			}
			
		}
		return 0;
		
	}

	private static void readTree(Node root, Queue queue) {
		if(root == null) return  ;
	
		if(root.left!=null) {
			readTree(root.left, queue);
		}
		if(root.right!=null) {
			readTree(root.right, queue);
		}		
		queue.add(root);
	}
	public static void main(String args[]) {
		Node root = new Node("-");
		root.left = new Node("4");
		root.right = new Node("7");
		evealuateExp(root);
	}
	
	static class Node {
		String data;
		Node left, right;

		Node(String data) {
			this.data = data;
			this.left = null;
			this.right = null;
		}
	}

}

