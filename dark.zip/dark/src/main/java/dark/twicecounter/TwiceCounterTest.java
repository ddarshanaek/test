package dark.twicecounter;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class TwiceCounterTest {
	
	public static void main(String args[]) {
		String a [] = {"b","b","hate", "love", "peace", "love", "peace", "hate", "love", "peace", "love", "peace", "a", "a"};
		System.out.println(countTwinWords(Arrays.asList(a)));
	}
	
	static int countTwinWords(List<String> list) {
		Map <String, Integer> map = new HashMap<String, Integer>();
		Map <String, Integer> twinMap = new HashMap<String, Integer>();

		
		for (String word : list) {
			Integer count = map.get(word);
			
			if(count!=null) {
				count++;
				map.put(word,count);
				if(count==2) {
					twinMap.put(word, Integer.valueOf(1));					
				}
				if(count==3) {
					twinMap.remove(word);
				}
			}else {
				map.put(word, Integer.valueOf(1));
			}
			
		}
		
		return twinMap.size();
	}

}


// Array = {"ABB", "CC", .... N} some words are repated twice