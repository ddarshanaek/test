package dark.graph;

import java.util.HashMap;
import java.util.LinkedList;

public class GraphTest {
	HashMap<Integer, Node> nodeList = new HashMap<Integer, Node>();
	
	
	public Node getNode(int id) {
		Node node = nodeList.get(id);
		if(node==null) {
			node = new Node(id);
		}
		return node;
	}
	
	public void addEdge(int source, int destination) {
		Node sourceNode = getNode(source);
		Node destinationNode = getNode(destination);
		sourceNode.adjacent.add(destinationNode);
	}
	

	
}

class GraphMatrix{
	private String[][] graphMatirx=null;
	public GraphMatrix(int n, int m) {
		graphMatirx = new String[n][m];
	}
	public void addValues() {
		graphMatirx[0][0] = "X"; graphMatirx[0][1] = "X"; graphMatirx[0][2] = "O";
		graphMatirx[1][0] = "O"; graphMatirx[1][1] = "O"; graphMatirx[1][2] = "O";
		graphMatirx[2][0] = "O"; graphMatirx[2][1] = "O"; graphMatirx[2][2] = "X";
		
	}
	
	public void getShapes() {
		for (int i = 0; i < graphMatirx.length; i++) {
			for (int j = 0; j < graphMatirx[i].length; j++) {
				if("X".equals(graphMatirx[j][j])) {
					
				}
			}
			
		}
	}
	
	
}

class Node{
	private int id;
	LinkedList <Node> adjacent = new LinkedList<Node>();
	
	Node(int id){
		this.id = id;
	}
}


// OOOO
// XXXX
// 0000
// OOOOXXO
//1// OXOXOOX
//2// XXXXOXO
//3// OXXXOOO

//    012
//0// XXO 
//1// OOX
//2// OXO
//3// OOO
//4// XOX
// XOX
// OXO
// XXO
// XXX
// OOO