package dark.inv;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.TreeSet;

public class InvestorSolution {

	public static void main(String args[]) {
		List<Integer> s = new ArrayList<Integer>();
		List<Integer> e = new ArrayList<Integer>();

		s.add(1);e.add(2);
		s.add(5);e.add(6);
		s.add(5);e.add(6);
		s.add(5);e.add(6);
		s.add(5);e.add(6);
		s.add(1);e.add(6);
		s.add(4);e.add(7);
		s.add(3);e.add(4);
		s.add(1);e.add(9);
		s.add(8);e.add(9);
		s.add(1);e.add(8);
		s.add(1);e.add(10);


		sortLists(s, e);
	}

	private static void sortLists(List<Integer> s, List<Integer> e) {
		TreeSet<InvAvailableDays> set = new TreeSet<InvAvailableDays>();
		List <Integer> listOfDays = new ArrayList<Integer>();
		int countDays = 0;
		int prevDay = 0;

		for (int i = 0; i < s.size(); i++) {
			InvAvailableDays invAvilableDaysObj = new InvAvailableDays(s.get(i), e.get(i));
			set.add(invAvilableDaysObj);
		}
		System.out.println(set);

		for (Iterator iterator = set.iterator(); iterator.hasNext();) {
			InvAvailableDays invAvailableDays = (InvAvailableDays) iterator.next();
			if (countDays == 0) {
				prevDay = invAvailableDays.getEndDate();
				countDays++;
				listOfDays.add(prevDay);
				continue;
			}
			if ((prevDay - 1) < invAvailableDays.getEndDate() && (prevDay - 1) >= invAvailableDays.getStartDate()) {
				prevDay = prevDay - 1;
				listOfDays.add(prevDay);
				countDays++;
			} else if((prevDay) >= invAvailableDays.getStartDate()){
				prevDay = prevDay-1;
				listOfDays.add(prevDay);
				countDays++;
			}
		}
		System.out.println(countDays);
		System.out.println(listOfDays);
	}

}

class InvAvailableDays implements Comparable<InvAvailableDays> {

	private int startDate;
	private int endDate;
	private int dateGap;

	public InvAvailableDays(int startDate, int endDate) {
		this.startDate = startDate;
		this.endDate = endDate;
		this.dateGap = this.endDate - this.startDate;
	}

	public int compareTo(InvAvailableDays obj) {
		if (this.endDate < obj.endDate) {
			return 1;
		} else if (this.endDate == obj.endDate) {
			if (this.dateGap > obj.dateGap) {
				return 1;
			}
		}
		return -1;
	}

	@Override
	public String toString() {
		return this.startDate + "-" + this.endDate;
	}

	public int getStartDate() {
		return startDate;
	}

	public void setStartDate(int startDate) {
		this.startDate = startDate;
	}

	public int getEndDate() {
		return endDate;
	}

	public void setEndDate(int endDate) {
		this.endDate = endDate;
	}

	public int getDateGap() {
		return dateGap;
	}

	public void setDateGap(int dateGap) {
		this.dateGap = dateGap;
	}

}