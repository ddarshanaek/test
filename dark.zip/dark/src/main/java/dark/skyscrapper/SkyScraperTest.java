package dark.skyscrapper;

import java.util.HashMap;
import java.util.Map;
import java.util.PriorityQueue;

public class SkyScraperTest {

	public static void main(String args[]) {
		PriorityQueue<Integer> pq= new PriorityQueue<Integer>();
		pq.add(4); pq.add(8);
		pq.add(9); pq.add(2); pq.add(5); pq.add(1);
		System.out.println(pq.poll());
		System.out.println(pq.poll());
		

	}
	static int solve(int[] arr) {
		int count = 0;
		int soFarMin = 0;
		int soFarMax = 0;
		Map<Integer , Integer> map = new HashMap<Integer, Integer>();
		
		for (int i = 0; i < arr.length; i++) {
			
			if(arr[i] >= soFarMin && arr[i]<=soFarMax ) {
				if(map.get(arr[i])!=null && map.get(arr[i])==1) {
					continue;
				}
				if(map.get(arr[i])==null) {
					continue;
				}
			}
			
			map.clear();
			for (int j = i+1; j < arr.length; j++) {
				
				Integer inCount = map.get(arr[j]);
				
				if(inCount!=null) {
					inCount++;
				}else {
					inCount = 1;
				}
				map.put(arr[j],inCount);
				
				if(arr[i]==arr[j]) {
					count++;
				}
				if(arr[i]<arr[j]) {
					soFarMax = arr[j];
					break;
				}
				if(arr[i]>=arr[j]) {
					soFarMin = arr[j];
				}
			}
		}
		return count*2;
	}
	
}
