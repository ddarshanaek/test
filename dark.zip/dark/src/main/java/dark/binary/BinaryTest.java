package dark.binary;

public class BinaryTest {
	
	public static int countSetBits(int n) {
		int count = 0;
		for(int i=1; i<=n; i++) {
			String binary = Integer.toBinaryString(i);
			for(int j=0; j<binary.length(); j++) {
				if('1' == binary.charAt(j)){
					count++;
				}
			}
			
		}
		return count;
	}

	public static void main(String args[]) {
		System.out.println(countSetBits(17));
		//System.out.println(Integer.bitCount(4));
	}
}
