package dark.bribing;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class BribeTest {
	
	public static void main(String args[]) {
		System.out.println(12%5);	
		System.out.println(downToZero(266574));
	}
	
	static int downToZero(int n) {
		int countToZero=0;
		int jumpCount = 0;
	    for(int i = n-1; i>=0; i--) {
	    	//System.out.println("###"+n%i);
	    	if(i==0 || i==1) {
	    		countToZero++;
	    	}
	    	else if(n%i != 0 ) {
	    		countToZero++;
	    	}else if(i>=n/i && i!=n){
	    		jumpCount++;
	    		countToZero=0;
	    	}else {
	    		countToZero++;
	    	}
	    }
	    return jumpCount+countToZero;
	}
	
	static int bribeCount(int[] q) {
		int bribeCount = 0;
		
		for (int i = 0; i < q.length; i++) {
			int gap = q[i]-i+1 ;
			if(gap>0) {
				bribeCount = bribeCount+gap;
			}else if(gap==0) {
				int gapWithBehind = q[i]-q[i+1];
				//if()
			}
		}
		
		
		int []c = new int[q.length];
		for (int i = 0; i < q.length; i++) {
			c[i]=i;
		}
		
		for (int i = 0; i < q.length; i++) {

			if(q[i] == i+1) {
				
			}else {
				//c[q[i]-1] - 				
			}
		}
		
		
		for (int i = 0; i < q.length; i++) {
			Person p = new Person();
			p.setNewPosition(i);
			p.setCorrectPosition(q[i]);
			
			if(q[i] == i+1) {
				p.setBribeCount(0);
			}else {
				p.setBribeCount(q[i]-i+1);
			}
		}
		return 1;
	}

}

class Person{
	
	private int correctPosition;
	private int newPosition;
	private List <Person> bribedBy = new ArrayList<Person>();
	private List <Person> bribeGiven = new ArrayList<Person>();
	private int bribeCount;
	
	public int getCorrectPosition() {
		return correctPosition;
	}
	public void setCorrectPosition(int correctPosition) {
		this.correctPosition = correctPosition;
	}
	public int getNewPosition() {
		return newPosition;
	}
	public void setNewPosition(int newPosition) {
		this.newPosition = newPosition;
	}
	public List<Person> getBribedBy() {
		return bribedBy;
	}
	public void setBribedBy(List<Person> bribedBy) {
		this.bribedBy = bribedBy;
	}
	public List<Person> getBribeGiven() {
		return bribeGiven;
	}
	public void setBribeGiven(List<Person> bribeGiven) {
		this.bribeGiven = bribeGiven;
	}
	public int getBribeCount() {
		return bribeCount;
	}
	public void setBribeCount(int bribeCount) {
		this.bribeCount = bribeCount;
	}
}



// 1,2,5,4,3,6,7
// 1,2,5,3,4,6,7


