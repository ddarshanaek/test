package dark.tree;

import java.util.Iterator;
import java.util.Objects;

public class Node {
	Node left;
	Node right;
	int data;

	public Node(int data) {
		this.data = data;
	}
	
	public void insert(int data) {
		if(this.data >= data) {
			if(this.left != null) {
				this.left.insert(data);
			}else {
				this.left = new Node(data);
			}
		}else {
			if(this.right!=null) {
				this.right.insert(data);
			}else {
				this.right = new Node(data);
			}
		}
		
	}
	
	public void printAll() {
		if(this.left !=null) {
			this.left.printAll();
		}
		System.out.println(data);
		if(this.right!=null) {
			this.right.printAll();
		}
	}
	
	public static void main(String args[]) {
		System.out.println(climbStairs(6));
		
	}
	public static int climbStairs(int n) {
        double max2Steps = 0;
        double combinationSteps = 0;
        double [] memo = new double[n];
        if(n%2==0){
            max2Steps = n/2;
        }else{
            max2Steps = (n-1)/2;
        }
        
        double fni=0;
        double fi=0;
        for(int i=1; i<=max2Steps; i++){
            if(memo[n-i]!=0){
                fni=memo[n-i];
            }else{
                memo[n-i] = fact(n-i);
                fni=memo[n-i];
            }
            if(memo[i]!=0){
                fi = memo[i];
            }else{
                memo[i] = fact(n-(i*2) + i-1);
                fi = memo[i];
            }
            combinationSteps  = combinationSteps + fni/fi;
                
        }
        return (int)combinationSteps + 1;
    }
    
    private static double fact(int a){
        double tmp = 1;
        for(int i =2 ; i <=a ; i++){
            tmp = tmp*i;
        }
        return tmp;
    }

}
