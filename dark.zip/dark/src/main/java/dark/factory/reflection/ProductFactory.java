package dark.factory.reflection;

import java.lang.reflect.Constructor;
import java.lang.reflect.InvocationTargetException;
import java.util.HashMap;

public class ProductFactory {
	private static ProductFactory instance;
	
	private ProductFactory() {
		
	}
	
	public static synchronized ProductFactory getInstance() {
		if(instance==null) {
			return new ProductFactory();
			
		}
		return instance;
	}

	private static HashMap<String, Class<?>> m_RegisteredProducts = new HashMap<String, Class<?>>();

	public void registerProduct(String productID, Class<?> productClass) {
		m_RegisteredProducts.put(productID, productClass);
	}

	public Product createProduct(String productID) throws NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		Class<?> productClass = (Class<?>) m_RegisteredProducts.get(productID);
		Constructor<?> productConstructor = productClass.getDeclaredConstructor();
		return (Product) productConstructor.newInstance();
	}
	
	public static void main(String args[]) throws NoSuchMethodException, SecurityException, InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException  {
		System.out.println("Start"); 
		Product p = ProductFactory.getInstance().createProduct("OneProduct");
		System.out.println(p);
		
		 
		Product p1 = ProductFactory.getInstance().createProduct("TwoProduct");
		System.out.println(p1);
		
	}
	
	static {
		try {
			Class.forName("dark.factory.reflection.OneProduct");
			Class.forName("dark.factory.reflection.TwoProduct");
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
}



interface Product{
	
}

abstract class AbstactProduct implements Product {
	private String prodName;
	private String id;
	public String getProdName() {
		return prodName;
	}
	public void setProdName(String prodName) {
		this.prodName = prodName;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}

}

class OneProduct extends AbstactProduct{
	static {
		ProductFactory.getInstance().registerProduct("OneProduct", OneProduct.class);
	}
	
}
class TwoProduct extends AbstactProduct{
	static {
		ProductFactory.getInstance().registerProduct("TwoProduct", TwoProduct.class);
	}
}


