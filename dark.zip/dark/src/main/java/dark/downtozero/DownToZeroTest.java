package dark.downtozero;

public class DownToZeroTest {
	
	public static void main(String args[]) {
		//System.out.println(Math.round(Math.sqrt(2)));
		System.out.println(downToZero(812849, 0,-1));
	}

	static int downToZero(int n, int count, int next) {
		double d = n;		
		int sqrt = (int)Math.round(Math.sqrt(d));
		int nextTry = 0;
		
		if(next!=-1) {
			nextTry = next;
		}else {
			nextTry = sqrt;
		}
		
		
		
		if(n==1 || n==2 || n==3) {
			count = downToZero(n-1, ++count, -1);
			System.out.println(n);
			return count;
		}
		
		if(n==0) {
			return count;
		}
		
		if(sqrt<2) {
			downToZero(n-1, ++count, -1);
			System.out.println(n);
		}
		
		if(sqrt!=1 && sqrt * sqrt == d) {
			count = downToZero(sqrt, ++count, -1);
			System.out.println(n);
		}else if(nextTry!=0 && nextTry!=1 && n%nextTry ==0) {
			count= downToZero(Math.max(n/(nextTry), nextTry), ++count, -1);
			System.out.println(n);
		}else if(nextTry!=0 && nextTry!=0 && (sqrt-nextTry)/(float)sqrt < 0.95f) {
			count= downToZero(n, count, --nextTry);
		}else {
			count = downToZero(n-1, ++count, -1);
			System.out.println(n);
		}
		
		return count;
	}
}


// 33 32 8  7  6  3 2 1 0
// 33 11 10 5  4  2 1 0
// 33 32 31 30 15 5 4 2 1 0


// Take the number start to divide by it'e nearest square root, 
	//if divisible then go ahead
		//increment the count ++
	
//again try to divide by  3, 4... n
	//if not divisible 
		//move down by one then count ++

//keep memoize of non divisible

	
//35 7  6  3  2  1  0
//36 6  3  2  1  0

// 10 5 4 2 1 0
// 10 9 3 2 1 0
// 26 13 12 4 2 1 0
// 26 25 5  4 2 1 0
// 50 10 5 4 2 1 0

//65 13 12 6 3 2 1 0
//65 64 8  4 2 1 0

