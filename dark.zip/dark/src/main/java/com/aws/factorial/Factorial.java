package com.aws.factorial;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class Factorial {

	static Map map = new HashMap();

	public static ArrayList<String>al=new ArrayList<String>(); 
	    private static void findsubsequences(String s, String ans) { 
	        if(s.length()==0) 
	        { 
	            al.add(ans);  
	            return; 
	        } 
	  
	                //we add adding 1st character in string            
	        findsubsequences(s.substring(1),ans+s.charAt(0)) ; 
	  
	                // Not adding first character of the string 
	                // because the concept of subsequence either  
	                // character will present or not 
	        findsubsequences(s.substring(1),ans);       
	    }

	public static void main(String args[]) {
        String s="abc"; 
        findsubsequences(s,"");    // Calling a function 
        System.out.println(al); 
        
		// int a =fact(4);
		// System.out.println(a);

		// double fib = fib(10000);
		// System.out.println(fib);
		// System.out.println(map);
		// 5*4*3*2*1

		int arr[] = {1, 2, 3, 4, 5}; 
        int r = 2; 
        int n = arr.length; 
       // printCombination(arr, n, r); 
	}

	private static double fib(int i) {

		if (i <= 0)
			return 0;
		if (i == 1)
			return 1;

		if (map.containsKey(i)) {
			return (Double) map.get(i);
		}

		double a = fib(i - 1) + fib(i - 2);
		map.put(i, a);

		return a;

	}

	static int fact(int i) {

		if (i == 0) {
			return 1;
		}
		int a = fact(i - 1);
		return i * a;

	}

	static List teams = new ArrayList();

	static void combinationUtil(int arr[], int n, int r, int index, int data[], int i) {
// Current combination is ready to be printed, print it 
		if (index == r) {
			for (int j = 0; j < r; j++)
				System.out.print(data[j] + " ");
			System.out.println("");
			return;
		}

// When no more elements are there to put in data[] 
		if (i >= n)
			return;

// current is included, put next at next location 
		data[index] = arr[i];
		combinationUtil(arr, n, r, index + 1, data, i + 1);

// current is excluded, replace it with next (Note that 
// i+1 is passed, but index is not changed) 
		combinationUtil(arr, n, r, index, data, i + 1);
	}

	static void printCombination(int arr[], int n, int r) {
		// A temporary array to store all combination one by one
		int data[] = new int[r];

		// Print all combination using temprary array 'data[]'
		combinationUtil(arr, n, r, 0, data, 0);
	}

}

//12 people are there print all 4 member team combination
// 
