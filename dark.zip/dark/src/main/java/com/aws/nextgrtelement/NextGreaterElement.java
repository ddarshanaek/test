package com.aws.nextgrtelement;

public class NextGreaterElement {
	
	
	
	public static void main(String args[]) {
		
		int a[] = new int[] {13, 7, 8,12};
		//-1,12,12,-1
		int max=0;
		
		for(int i=0; i<a.length ; i++) {
			boolean found = false;
			for(int j=i; j<a.length ; j++) {
				if(a[j]>max) {
					max = a[j];
				}
				
				
				if(a[i] < a[j]) {
					System.out.println(a[j]);
					found = true;
					break;
				}
			}
			if(!found){
				System.out.println(-1);
			}
		}
		
	}

}
