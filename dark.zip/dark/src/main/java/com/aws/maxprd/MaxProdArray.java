package com.aws.maxprd;

import java.util.Arrays;

public class MaxProdArray {
	
	public static void main(String args[]) {
		
		int a[] = new int[] {1, 4, 3, 6, 7, 10,1,1,1,1,1,1,1,1,1,20,1,1,1,1,1} ;
		
		
		findMaxProd(a);
		
	}

	private static void findMaxProd(int[] a) {
		
		int maxPair[] = new int[2];
		findMaxProd(a, 0, 0,maxPair);
		System.out.println(Arrays.toString(maxPair));
		
	}

	private static void findMaxProd(int[] a, int max, int current, int maxPair[]) {
		
		if(current == a.length) return;
		
		int tmp = 0;
		for(int i=current+1; i<a.length; i++) {
			tmp = a[current] * a [i];
			if(tmp>max) {
				max = tmp;
				maxPair[0] = current;
				maxPair[1] = i;
				
			}
		}
		findMaxProd(a,max,current+1,maxPair);
		
	}

}
