package com.aws.linklist;

public class LinkListTest {

	Node head;

	void printList() {
		Node temp = head;
		while (temp != null) {
			System.out.print(temp.data + " ");
			temp = temp.next;
		}
		System.out.println();
	}

	void printList(Node temp) {
		//Node temp = head;
		while (temp != null) {
			System.out.print(temp.data + " ");
			temp = temp.next;
		}
		System.out.println();
	}
	/* Inserts a new Node at front of the list. */
	public void push(int new_data) {
		/*
		 * 1 & 2: Allocate the Node & Put in the data
		 */
		Node new_node = new Node(new_data);

		/* 3. Make next of new Node as head */
		new_node.next = head;

		/* 4. Move the head to point to new Node */
		head = new_node;
	}

	private void reverse(Node head, int i, int k) {
		// TODO Auto-generated method stub
		if (head == null)
			return;

		if (i == 0)
			reverse(head, k, k);

		if (i > 0) {
			Node tmp = head; 
			head = head.next;
			head.next = tmp;
			i--;
			reverse(head.next, i, k);

		}
	}

	public static void main(String args[]) {

		LinkListTest llist = new LinkListTest();

		/*
		 * Constructed Linked List is 1->2->3->4->5->6-> 7->8->8->9->null
		 */
		llist.push(9);
		llist.push(8);
		llist.push(7);
		llist.push(6);
		llist.push(5);
		llist.push(4);
		llist.push(3);
		llist.push(2);
		llist.push(1);
		
		//llist.printList();

		//llist.reverse(llist.head, 4, 4);
		
		//llist.printList();

		llist.addNumber();
		
	}

	Node head1;
	Node head2;
	private  void addNumber() {
		LinkListTest list = new LinkListTest();
		
        // creating first list 
        list.head1 = new Node(7); 
        list.head1.next = new Node(5); 
        list.head1.next.next = new Node(9); 
        list.head1.next.next.next = new Node(4); 
        list.head1.next.next.next.next = new Node(6); 
        System.out.print("First List is "); 
        list.printList(list.head1); 
  
        // creating seconnd list 
        list.head2 = new Node(8); 
        list.head2.next = new Node(4); 
        System.out.print("Second List is "); 
        list.printList(list.head2); 
  
        // add the two lists and see the result 
        Node rs = list.addTwoLists(list.head1, list.head2); 
       // System.out.print("Resultant List is "); 
       // list.printList(rs); 
		
	}

	private Node addTwoLists(Node head12, Node head22) {
		
		String head1 = "";
		String head2 = "";
		
		while (head12 != null || head22 != null ) {
			if(head12 != null) {
				head1 = head1+head12.data ;
				head12 = head12.next;
			}
			if(head22 != null) {
				head2 = head2 +head22.data ;
				head22 = head22.next;
			}

		}
		System.out.println(head1);
		System.out.println(head2);
		
		return null;
	}

}

class Node {
	int data;
	Node next;

	Node(int d) {
		data = d;
		next = null;
	}
}
