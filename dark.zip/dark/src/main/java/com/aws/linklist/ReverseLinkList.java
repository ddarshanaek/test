package com.aws.linklist;

import java.util.Stack;

public class ReverseLinkList {

	
	public static void main(String args[]) {
		String a = "1";
		System.out.println(~2);
		
		Node root= new Node(1);
		root.next = new Node(2);
		root.next.next = new Node(3);
		root.next.next.next = new Node(4);
		
		print(root);
		
		reverse(root, new Stack());
		

		print(root);
	}

	private static void print(Node root) {
		if(root==null) return;
		System.out.println(root.data);
		print(root.next);
		
	}
	
	private static void reverse(Node root, Stack stack) {
		if(root==null) return;
		
		
		
		if(root.next == null) {
			while(!stack.isEmpty()) {
				root.next = (Node)stack.pop();
				root.next.next = null;
				root = root.next;
				
			}
			return;
		}
		
		stack.add(root);
		
		reverse(root.next, stack);
		
	}
	
}
