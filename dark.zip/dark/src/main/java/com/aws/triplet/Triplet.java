package com.aws.triplet;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;

public class Triplet {
	
	public static void main(String args[]) {
		
		int arr[] = new int[] {3, 2, 4, 6, 5,1,6,7,8,9};
		Arrays.sort(arr);
		List<Double> expl = new ArrayList<Double>(); 
		List<Double> sum = new ArrayList<Double>(); 
		
		
		
		for(int i=0; i< arr.length; i++) {
			
			expl.add(Math.pow(arr[i], 2));
			
			
		}
		System.out.println(expl);
		boolean found = false;

		for (int i = 0; i < expl.size(); i++) {
			for (int j = i+1; j < expl.size(); j++) {
				
				if(expl.contains(expl.get(i) + expl.get(j))) {
					
					sum.add(expl.get(i) + expl.get(j));
				}
			}
			if(found) {
				break;
			}
		}
		System.out.println(sum);
	}

}
