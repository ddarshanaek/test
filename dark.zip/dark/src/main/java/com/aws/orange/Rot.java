package com.aws.orange;

import java.util.Arrays;

public class Rot {

	public static void main(String args[]) {
		
		String a = "2 1 0 2 1 1 0 1 2 1 1 0 0 2 1";
		char i[][] = new char[3][5];
		
		int index = 0;
		
		for(int x=0; x<i.length; x++) {
			for(int j=0; j<i[x].length; j++) {
				i[x][j] = a.charAt(index);
				index = index + 2;
			}
		}
		for(int y = 0; y<i.length; y++) {
			System.out.println(Arrays.toString(i[y]));
		}
		
		findRotTime(i);
		
	}

	private static void findRotTime(char[][] i) {
		for(int x=0; x<i.length; x++) {
			for(int j=0; j<i[x].length; j++) {
				if('1'==i[x][j]) {
					
				}
				
			}
		}
		
	}
}


//x,j = x-1, j-1
//x-1, j
//x, j-1
//x+1, j
//x+1,j+1
//x+1, j-1
//x-1,j+1
//x-1, j-1



//{{{}}}{}


