package com.aws.stack;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Stack;

public class SpecialStack {
	
	Stack stack = new Stack();
	Stack <Integer> min = new Stack();
	
	public void add(int i){
		
		if(min.isEmpty()) {
			min.add(i);
		}else if(min.peek()>i) {
			min.add(i);
			
		}else {
			
			min.add(min.peek());

		}
		
		stack.add(i);
	}
	
	public Object pop() {
		Object obj = stack.pop();
		min.pop();
		return obj;
	}
	
	public int getMin() {
		return min.peek();
	}
	
	
	public static void main(String args[]) {
		SpecialStack sp = new SpecialStack();
		sp.add(10);
		sp.add(9);
		sp.add(3);
		sp.add(3);
		sp.add(4);
		sp.add(10);
		sp.add(4);
		sp.add(4);
		sp.add(4);
		sp.add(4);
		sp.add(4);
		System.out.println(sp.getMin());
		System.out.println(sp.pop());
		System.out.println(sp.pop());
		System.out.println(sp.pop());
		System.out.println(sp.pop());
		System.out.println(sp.getMin());
		System.out.println(sp.pop());
		System.out.println(sp.pop());
		System.out.println(sp.getMin());
		System.out.println(sp.pop());
		System.out.println(sp.pop());
		System.out.println(sp.pop());
		System.out.println(sp.getMin());
	}

}
