package com.aws.matrix;

public class Matrix {

	
	public static void main(String args[]) {
		 int mat[][] = { 
                 {1, 1, 1}, 
                 {2, 2, 2}, 
                 {3, 3, 3} 
             }; 
		 int[][] matt = new int[3][3];
		//System.out.println(mat[0].length);
		 transpose(mat, matt );
		 print(matt);
	}

	private static void transpose(int[][] mat, int[][] matt) {
		for (int i=0; i<3; i++) {
			for(int j=0; j<3; j++) {
				matt[i][j] = mat[j][i];
			}
		}
		
	}

	private static void print(int[][] mat) {
		
		for(int i=0; i<mat.length; i++) {
			for (int j = 0; j < mat[i].length; j++) {
				System.out.print(mat[i][j]);
				System.out.print(" ");
			}
			System.out.println("");
		}
		
	}
}
