package com.aws.binarytree;

public class BinarySearch {

	public static void main(String args[]) {
		int input[] = new int[100000] ;
		
		for(int i=0; i<100000; i++) {
			input[i] = i;
		}
		

		boolean found = binarySearch(input, 1, 0, input.length);
		
		System.out.println(found);
	}

	private static boolean binarySearch(int[] input, int key, int start, int end) {

		
		int tmp = input[(start+end)/2];
		if(tmp==key) {
			return true;
		}
		if((start+end)/2==input.length-1) {
			return false;
		}
		
		if(key>tmp) {
			return binarySearch(input, key, (start+end)/2, end);
		}else {
			return binarySearch(input, key, start, (start+end)/2);
		}
		
		
	}

}
