package com.aws.binarytree;

import java.util.ArrayList;
import java.util.List;

public class FixBinaryTree {
	
	
	public static void main(String args[]) {
		
        /* Constructing below tree 
        5 
      /   \ 
     3     6 
    / \     \ 
   1   4     8 
  / \       / \ 
 0   2     7   9  */

		BinaryTree tree = new BinaryTree();
		tree.root = new Node(5);
		tree.root.left = new Node(3);
		tree.root.right = new Node(4);
		tree.root.left.right = new Node(4);
		tree.root.left.left = new Node(1);
		tree.root.right.right = new Node(8);
		tree.root.left.left.right = new Node(2);
		tree.root.left.left.left = new Node(0);
		tree.root.right.right.left = new Node(7);
		tree.root.right.right.right = new Node(9);
		
		fixTree(tree.root);
		 
	}

	private static void fixTree(Node root) {
		List list = new ArrayList();
		
		fixTree(root, list);
		System.out.println(list);
		
		for(int i=0; i<list.size() ; i ++) {
			Node tmp = (Node)list.get(i);
			//add()
		}
		
		
	}

	private static void fixTree(Node root, List list) {
		if(root == null) {return ;}
		
		if(root.data>root.right.data) {
			list.add(root.right);
			root.right = null;
			return;
		}
		if(root.data<root.left.data) {
			list.add(root.left);
			root.left = null;
			return;
		}
		fixTree(root.left,  list) ;
		

		fixTree(root.right,  list) ;
	}

}
