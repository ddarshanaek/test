package com.aws.binarytree;

import java.util.Stack;

public class MaxDiff {
	
	static Node head;
	
	public static void main (String args[]) {
		String input = "1118111";
		
		populateTree(input);
		
		getMaxDiff(head);
		
	}

	private static void getMaxDiff(Node head) {
		
		int max = getMaxDiff(head, Integer.MIN_VALUE) ;
		System.out.println(max);
	}
	
	

	private static int  getMaxDiff(Node head, int max) {
		
		if(head==null) {
			return max;
		}
		
		int left = 0;
		if(head.left!=null) {
			left = head.data - head.left.data;
			max = max>left?max:left;
		}
		int right = 0;
		if(head.right!=null) {
			right = head.data - head.right.data;
			max = max>right?max:right;
		}
		
		
		

		max = getMaxDiff(head.left, max);
		max = getMaxDiff(head.right, max);
		
		return max;
		
	}

	private static void populateTree(String input) {
		Stack inputStack = converStringTostack(input);
		
		//Node head = null;
		String headString = Character.toString((Character) inputStack.pop()) ;
		if(!"N".equals(headString)) {
			head = new Node((Integer.valueOf(headString)) );
		}
		
		
		pupulateTree(inputStack, head);
		System.out.println("");
		
	}

	private static void pupulateTree(Stack inputStack, Node head) {
		
		if(inputStack.isEmpty()) {
			return;
		}
		
		if(head == null) {
			String headString = Character.toString((Character) inputStack.pop()) ;
			if(!"N".equals(headString)) {
				head = new Node((Integer.valueOf(headString)) );
			}
			
		}
		
		String left = Character.toString((Character) inputStack.pop()) ;
		if(!"N".equals(left)) {
			head.left = new Node((Integer.valueOf(left)) );
			
		}
		String right = Character.toString((Character) inputStack.pop()) ;
		if(!"N".equals(right)) {
			head.right = new Node((Integer.valueOf(right)) );
			
		}		
		if(head.left!=null) pupulateTree(inputStack, head.left);
		if(head.right!=null) pupulateTree(inputStack, head.right);
	}

	private static Stack converStringTostack(String input) {
		Stack inputStack = new Stack();
		for(int i=input.length()-1; i>=0 ; i--) {
			inputStack.push(input.charAt(i));
		}
		
		return inputStack;
	}

}



