package com.aws.binarytree;

import java.util.ArrayList;
import java.util.List;

public class BinaryTree {
	static Node root;
	private static boolean found;
	

	public static void main(String[] args)  
    { 
        /* Constructing below tree 
               5 
             /   \ 
            3     6 
           / \     \ 
          1   4     8 
         / \       / \ 
        0   2     7   9  */
          
        BinaryTree tree = new BinaryTree(); 
        tree.root = new Node(5); 
        tree.root.left = new Node(3); 
        tree.root.right = new Node(6); 
        tree.root.left.right = new Node(4); 
        tree.root.left.left = new Node(1); 
        tree.root.right.right = new Node(8); 
        tree.root.left.left.right = new Node(2); 
        tree.root.left.left.left = new Node(0); 
        tree.root.right.right.left = new Node(7); 
        tree.root.right.right.right = new Node(9); 
//  
//        tree.insert(4);
//        System.out.println("done");
//        inorder();
        
        LCA(0,4);
    } 
	
	private static void LCA(int i, int j) {
	 List<Integer> list = new ArrayList<Integer>(); 
	 List<Integer> a = new ArrayList<Integer>(); 
	 
		if(search(root, i,list, a)){
			
			if (list.contains(j) && a.isEmpty()) {
				a.add(j);
				System.out.println(a);
				return;
			}
			if(search(root, j,list, a)) {
				System.out.println(a);
			}
		}
		
		//list.add(root.data);
		System.out.println(list);
		
	}

	private static boolean search(Node root, int i, List<Integer> list, List<Integer> a) {


		if (root == null)
			return false;


		
		if (root.data == i) {
			list.add(root.data);
			
			return true;

		} else {
			if(search(root.left, i, list, a)) {
				if (list.contains(root.data) && a.isEmpty()) {
					a.add(root.data);
				}
				list.add(root.data);
				
				return true;
			}

			if(search(root.right, i, list, a)) {
				if (list.contains(root.data)&& a.isEmpty()) {
					a.add(root.data);
				}
				list.add(root.data);
				
				return true;
			}
			return false;
		}

	}

	private static void search(int i) {
		
		
	}

	public static void insert(int a) {
		insert(root, a);
	}

	private static Node insert(Node root, int a) {
		if(root==null) {
			root = new Node(a);
			return root;
		}
		
		if(a>root.data) {
			root.right = insert(root.right, a);
 		}else if(a<=root.data) {
			root.left = insert(root.left, a);
		}
		return root;
	}
	
    static void inorder()  { 
        inorderRec(root); 
     } 
   
     // A utility function to do inorder traversal of BST 
     static void inorderRec(Node root) { 
         if (root != null) {
        	 System.out.println(root.data); 
             inorderRec(root.left); 
            
             inorderRec(root.right); 
             
         } 
     } 
	
}


class Node  
{ 
    int data; 
    Node left, right; 
  
    public Node(int data)  
    { 
        this.data = data; 
        left = right = null; 
    } 
} 