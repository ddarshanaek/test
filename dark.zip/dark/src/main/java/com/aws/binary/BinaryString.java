package com.aws.binary;

public class BinaryString {
	
	public static void main(String args[]) {
		
		String s = "00100101000001011110";
		
		//findStartEndWithOne(s,0);
		
		findStartEndWithOne_("abc",0, 0);
	}

	private static void findStartEndWithOne(String s, int current) {
		
		if(s.length() == current) return;
		int start=-1;
		
		for(int i=current; i<s.length(); i++) {
			if('1' == s.charAt(i) && start ==-1) {
				start = i;
				current = start;
			}else if ('1' == s.charAt(i)) {
				System.out.println(s.substring(start,i+1));
			}
		}
		
		findStartEndWithOne(s, current+1);
		
	}
	
	private static void findStartEndWithOne_(String s, int start, int end) {
		
		if(s.length() == end) return;

		System.out.println(s.substring(start,start));
		
		findStartEndWithOne_(s, start, end+1);
		
		//findStartEndWithOne_(s.substring(current), );
		
		
		
	}

}
